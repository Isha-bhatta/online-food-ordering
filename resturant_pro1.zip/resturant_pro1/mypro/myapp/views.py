from django.shortcuts import render, redirect
from django.contrib import messages
from myapp.models import Contact
from .forms import CustomUserCreationForm

def about(request):
    return render(request, 'testapp/about.html')

def dashboard(request):
    return render(request, 'testapp/dashboard.html')

def main(request):
    return render(request, 'testapp/main.html')

def Menu(request):
    return render(request, 'testapp/Menu.html')
def home(request):
    return render(request, 'testapp/home.html')


def contact_us(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        subject = request.POST.get("subject")
        message = request.POST.get("message")
        
        # Save the feedback to the database
        contact = Contact.objects.create(name=name, email=email, subject=subject, message=message)
        
        # Redirect to the same page (or any other appropriate page)
        return redirect('contact')  # Assuming you have a URL name 'contact'

    return render(request, 'testapp/contact.html')


def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  # Redirect to login page
    else:
        form = CustomUserCreationForm()
    return render(request, 'testapp/register.html', {'form': form})