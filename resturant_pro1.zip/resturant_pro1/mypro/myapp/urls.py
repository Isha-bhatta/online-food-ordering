from django.urls import path
from .views import register

from . import views

urlpatterns = [
    path('', views.main, name='main'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('about/', views.about, name='about'),
    path('Menu/', views.Menu, name='Menu'),
    path('contact/', views.contact_us, name='contact'),
    # Add the following line for the contact form submission
    path('contact/submit-feedback/', views.contact_us, name='submit_feedback'),
    path('register/', register, name='register'),
]
    

